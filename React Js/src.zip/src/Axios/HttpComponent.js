import React, {Component} from 'react';
import Axios from 'axios';

class HttpComponent extends Component {

        state(){

        }

        render(){
                return ( <div>
                    done
                </div>)
          
        }

        constructor(props){
            console.log('Constructor called');
            super(props);
        }
    
        static getDerivedStateFromProps(props, state) {
            console.log('getDerivedStateFromProps called');
            return state;
        }
    
        componentDidMount = () => {
            Axios.get('https://jsonplaceholder.typicode.com/todos')
            .then(function (response) {
             // handle success
            console.log(response);
             })
             .catch(function (error) {
             // handle error
             console.log(error);
             })
             .finally(function () {
              // always executed
             });
            console.log('componentDidMount called');
        }
    
        shouldComponentUpdate = (nextProps, nextState) => {
            console.log('shouldComponentUpdate called');
            return true;
        }
    
        getSnapshotBeforeUpdate = (prevProps, prevState) => {
            console.log('getSnapshotBeforeUpdate called');
            return {message: 'Test'};
        }
    
        componentDidUpdate = () => {
            console.log('componentDidUpdate called');
        }

}

export default HttpComponent;