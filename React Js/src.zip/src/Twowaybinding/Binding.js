import React,{useState} from 'react';

const Binding =() => {
    const [currState, setState] = useState({title: "Jaishree", role: '', clickcount:0});

    const titleChangedHandler = (event) => {
        const updatedanswer = event.target.value;
        currState.title = updatedanswer;
        setState ({ title : currState.title, role: currState.role, clickcount: currState.clickcount})
    }

    const roleChangeHandler = (event) => {
        const updatedrole = event.target.value;
        currState.role = updatedrole;
        setState ({title: currState.title, role: currState.role, clickcount: currState.clickcount})
    }

    const clicksubmit = (event) => {
        event.preventDefault();
        console.log(currState.title);
        console.log(currState.role);
    }

    const clickcount = () => {
        console.log(currState.clickcount);
        currState.clickcount+=1;
        setState ({title: currState.title, role: currState.role, clickcount: currState.clickcount})
        console.log(currState.clickcount);
    }

    return(
        <div>
            <center>
              <h1>FORM</h1> <br></br>
              <form onSubmit={(event) => clicksubmit(event)}>
              <b>TITLE : </b><label><input type ="text" value={currState.title} onChange={(event) => titleChangedHandler(event)}></input></label> 
              <button type="button">Search</button><br></br>
              <b>ROLE : </b>
                <select name="role" onChange={(event) => roleChangeHandler(event)}>
                <option value=""></option>
                  <option value="Developer">Developer</option>
                  <option value="Tester">Tester</option>
                  <option value="SystemEngineer">System Engineer</option>
                  <option value="HR">HR</option>
                </select><br></br>
                <input type="submit" value="Submit"/><br></br>
                </form>
              <div>
                  <h4>Count : {currState.clickcount}</h4> 
                  <input type = "button" value= "Increment" onClick={clickcount}/>
              </div>
            </center>
            <br></br>
        </div>
    );
}

export default Binding;