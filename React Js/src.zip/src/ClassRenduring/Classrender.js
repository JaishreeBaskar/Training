import React from 'react';

    class Classrender extends React.Component{

        state={
            title:'',
            role:''
        };

        titleChangedHandler = (event) => {
        const updatedanswer = event.target.value;
        this.setState({title:updatedanswer})
        console.log(this.updatedanswer);
    }

        roleChangeHandler = (event) => {
        const updatedrole = event.target.value;
        this.setState({role:updatedrole});
        console.log(this.updatedrole);
    }

        clicksubmit = (event) => {
        event.preventDefault();
        console.log(this.state);
        console.log("on clicking submit");
    }

    showSearch=() =>{
        console.log(this.state.title);
        console.log("clicked search");      
    }    

    render(){
    return(
        <div>
            <center>
              <h1>FORM</h1> <br></br>
              <form onSubmit={(event) => this.clicksubmit(event)}>
              <b>TITLE : </b><label><input type ="text" value={this.state.title} onChange={(event) => this.titleChangedHandler(event)}></input></label> 
              <button type="button" onClick={this.showSearch}>Search</button><br></br>
              <b>ROLE : </b>
                <select name="role" onChange={(event) => this.roleChangeHandler(event)}>
                  <option value=""></option>
                  <option value="Developer">Developer</option>
                  <option value="Tester">Tester</option>
                  <option value="SystemEngineer">System Engineer</option>
                  <option value="HR">HR</option>
                </select><br></br>
                <input type="submit" value="Submit"/><br></br>
                </form>
            </center>
        </div>
    );
}
}
export default Classrender ;