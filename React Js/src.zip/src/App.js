import React from 'react';
import './App.css';
import HttpComponent from './Axios/HttpComponent';
//import Binding from './Twowaybinding/Binding';
//import Classrender from './ClassRenduring/Classrender';
//import Todos from './Lifecycle/Todos';

function App() {
  return (
 // <Binding/>
 //<Classrender/>
 //<Todos/>
 <HttpComponent/>
  );
}

export default App;
