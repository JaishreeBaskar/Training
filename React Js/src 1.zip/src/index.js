import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import {createStore, combineReducers, applyMiddleware} from 'redux';
import reducer from './redux/learn/redux/reducer';
import { Provider } from 'react-redux';
import ResultReducer from './redux/learn/redux/ResultReducer';
import CountReducer from './redux/learn/redux/CountReducer';
import thunk from 'redux-thunk';
import Reducer from './Project/Reducer';
import todoReducer from './unit-testing/TodoReducer';
 
// // to break the reducers and combine it later
// const rootReducer = combineReducers({
//     ctr: CountReducer,
//     res: ResultReducer
// })
// //redux store example - connecting store to redux
// const store = createStore(rootReducer);

//const store = createStore(reducer);

//especially for project 
//const store = createStore(Reducer);

//for testing
const store = createStore(todoReducer);

const logger = store => {
    return next => {
        return action => {
            console.log('[Middleware] dispatching ', action);
            console.log('[Middleware] before state', store.getState());
            const result = next(action);
            console.log('[Middleware] after state', store.getState());
            return result;
        } 
    }
}
// const rootReducer = combineReducers({cRed: CountReducer, rRed: ResultReducer});
// const store = createStore(rootReducer, applyMiddleware(logger, thunk)); 

ReactDOM.render(<Provider store = {store}><App /></Provider>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
