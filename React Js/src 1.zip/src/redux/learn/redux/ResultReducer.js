const initialState = {
    // counter: 10,
    results: []
}

const ResultReducer = (state = initialState, action) => {

    switch(action.type){
        case 'STORE_RESULT':
                    return {
                            ...state,
                            results: state.results.concat({value: action.value})
                            //to store values in array
                        }
    }
    return state;
}
 
export default ResultReducer;