const initialState = {
    counter: 10,
    //results: []
}

const CountReducer = (state = initialState, action) => {

    switch(action.type){
        case 'INC_COUNTER':
            return {
                ...state,
                counter: state.counter + 1  
            }
        case 'DEC_COUNTER':
            return {
                    ...state,
                    counter: state.counter - 1  
                }
        case 'ADD_COUNTER':
            return {
                    ...state,
                    counter: state.counter + 5
                }
        case 'SUB_COUNTER':
            return {
                    ...state,
                    counter: state.counter - 5
                }
    }
    return state;
}
 
export default CountReducer;