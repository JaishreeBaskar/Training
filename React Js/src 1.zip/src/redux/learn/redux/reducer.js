const initialState = {
    counter: 10,
    results: []
}

const reducer = (state = initialState, action) => {

    switch(action.type){
        case 'INC_COUNTER':
            return {
                ...state,
                counter: state.counter + 1  
            }
        case 'DEC_COUNTER':
            return {
                    ...state,
                    counter: state.counter - 1  
                }
        case 'ADD_COUNTER':
            return {
                    ...state,
                    counter: state.counter + 5
                }
        case 'SUB_COUNTER':
            return {
                    ...state,
                    counter: state.counter - 5
                }
        case 'STORE_RESULT':
                    return {
                            ...state,
                            results: state.results.concat({value: state.counter})
                            //to store values in array
                        }
    }
    return state;
}

//     if(action.type === 'INC_COUNTER'){
//         return {
//             ...state,
//             counter: state.counter + 1
//         }
//     }
//     else if(action.type === 'DEC_COUNTER'){
//         return {
//             ...state,
//             counter: state.counter - 1
//         }
//     }
//     else if(action.type === 'ADD_COUNTER'){
//         return {
//             ...state,
//             counter: state.counter + 5
//         }
//     }
//     else if(action.type === 'SUB_COUNTER'){
//         return {
//             ...state,
//             counter: state.counter - 5
//         }
//     }
//     return state;
 
export default reducer;