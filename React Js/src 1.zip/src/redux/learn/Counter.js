// //original 
import React, { Component } from 'react';
import CounterControl from './CounterControl/CounterControl';
import CounterOutput from './CounterOutput/CounterOutput';
import {connect} from 'react-redux';
import * as actionCreator from './redux/Actions'

 // mapping state from store to props (subscription)
const mapStateToProps = state => {
    return {
        //ctr: state.counter,
        //to store 
        //storedResult: state.results
        //reducer combining
        ctr: state.cRed.counter,
        storedResult: state.rRed.results
    };
};

// dispatching actions
const mapDispatchToProps = dispatch => {
    return{

        // onIncrementCounter:() => dispatch(actionCreator.increment()),
        //below for thunk
        onIncrementCounter:() => dispatch(actionCreator.asynCallAndIncrement()),
        onDecrementCounter:() => dispatch(actionCreator.decrement()),
        onAddCounter:() => dispatch(actionCreator.addCounter(5)),
        onSubCounter:() => dispatch(actionCreator.subCounter(5)),
        onStoreResult: (value) => dispatch(actionCreator.onStoreResult(value)),

        //using timeout
        //onIncremnentCounter:() => dispatch(actionCreator.asynCallAndIncrement())

        // onIncremnentCounter: () => dispatch({type: 'INC_COUNTER'}),
        // onDecremnentCounter: () => dispatch({type: 'DEC_COUNTER'}),
        // onAddCounter: () => dispatch({type: 'ADD_COUNTER'}),
        // onSubtractCounter: () => dispatch({type: 'SUB_COUNTER'}),
        // onStoreResult: () => dispatch({type: 'STORE_RESULT'}),
    };
};

class Counter extends Component {

    render () {
        return (
            [<div key = "1">
                <center>
                <CounterOutput value={this.props.ctr} />
                {/* <CounterOutput value='0' /> */}
                {/* <CounterControl label="Increment"/>
                <CounterControl label="Decrement"/>
                <CounterControl label="Add 5"/>
                <CounterControl label="Subtract 5"/> */}
                <CounterControl label = "Increment 1" clicked={this.props.onIncrementCounter}/>
                <CounterControl label = "Decrement 1" clicked={this.props.onDecrementCounter}/>
                <CounterControl label = "Add 5" clicked={this.props.onAddCounter}/>
                <CounterControl label = "Subtract 5" clicked={this.props.onSubCounter}/>
                
                <hr/>
                <button onClick = {()=> this.props.onStoreResult(this.props.ctr)}>Store Result
                </button>
                {/* <button onClick={this.props.onStoreResult}>Store Result</button> */}
                </center>
            </div>,
            <div key = "2"><center>
                {
                    this.props.storedResult.map(result => {
                        return <div>{result.value}</div>
                    })
                }
                </center> 
            </div>
            ]
        );
    }
}

//export default Counter;
//export default connect(mapStateToProps)(Counter);
export default connect(mapStateToProps, mapDispatchToProps)(Counter);















// import React, { Component } from 'react';
// import CounterControl from './CounterControl/CounterControl';
// import CounterOutput from './CounterOutput/CounterOutput';
// import { connect } from 'react-redux';


// class Counter extends Component {
//     render () {
//         return (
//             <div>
//                 <CounterOutput value={this.props.ctr} />
//                 <CounterControl label="Increment" clicked={this.props.onIncrementCounter}/>
//                 <CounterControl label="Decrement"/>
//                 <CounterControl label="Add 5"/>
//                 <CounterControl label="Subtract 5"/>
//                 <hr/>
//                 <button>Store Result</button>
//             </div>
//         );
//     }
// }

// const mapStateToProps = state => {
//     return {
//         ctr: state.counter
//     }
// }

// const mapDispatchToProps = dispatch => {
//     return {
//         onIncrementCounter: () => dispatch({type: 'INC_COUNTER'})
//     }
// }

// export default connect(mapStateToProps, mapDispatchToProps)(Counter);