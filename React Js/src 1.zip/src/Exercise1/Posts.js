import React, { Component } from 'react';
import axios from 'axios';

class Posts extends Component {

    state = {
        posts: [{
            userId: '',
            id: ''
        }]
    }

    componentDidMount = () => {
        axios.get('https://jsonplaceholder.typicode.com/posts')
            .then((response) => {
                const posts = response.data;
                this.setState({ posts });
                console.log("Posts", response.data);
            })
            .catch((error) => {
                console.log("Error getting data");
            })
    }

    addCommentHandler = (userId) => {
        alert('You commented on user ' + userId+' post ' );
    }

    render() {
        return <div className="container">
            <h3><center>Posts</center></h3>
            <div className="row justify-content-center">
                {this.state.posts.map(post => <div className="card col-lg-8 m-3">
                    <h6 className="mt-2">{post.title}</h6>
                    <div className="card-body">{post.body}</div>
                    <div>
                        <label>Comment</label><br></br>
                        <input type="text" className="comment-box" placeholder="Enter your text"></input>
                        &nbsp;<button className="btn-xs ml-auto btn-secondary mb-2" onClick={() => this.addCommentHandler(post.userId)}>Add</button>
                    </div>
                </div>)}
            </div>
        </div>
    }
}

export default Posts;