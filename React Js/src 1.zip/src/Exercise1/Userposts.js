import React, { Component } from 'react';

class UserPosts extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return <div className="container post">
            <div className="row justify-content-center">
                <div className="card col-lg-8 m-3">
                    <div><b>Title : </b>{this.props.title}</div>
                    <div className="card-body"><b>Body : </b>{this.props.body}</div>
                    <div className="ml-auto"><button className="btn-sm btn-secondary mb-2" onClick={() => this.props.removePost(this.props.id)}><b>Delete</b></button></div>
                </div>
            </div>
        </div>
    }
}

export default UserPosts;