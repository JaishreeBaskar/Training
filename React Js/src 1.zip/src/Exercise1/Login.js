import React from 'react';

    class Login  extends React.Component{

    state={
        getusername:'',
        getpassword:''
    };

    usernameChangedHandler = (event) => {
        const updatedusername = event.target.value;
        this.setState({getusername:updatedusername})
        console.log(updatedusername);
    }

    passwordChangedHandler = (event) => {
        const updatedpassword = event.target.value;
        this.setState({getpassword:updatedpassword})
        console.log(updatedpassword);
    }

    clicksubmit = (event) => {
        event.preventDefault();
        console.log(this.state);
        console.log("login clicked");
    }

    render(){
    return(
        <div className="login">       
            <center>
              <h1> LOGIN </h1> <br></br>
              <form onSubmit={(event) => this.clicksubmit(event)}>
                <table>
                    <tbody>
              <tr><td><b>USER NAME : </b></td><td><label><input type ="text" value={this.state.getusername} onChange={(event) => this.usernameChangedHandler(event)}/></label></td></tr>
              <tr><td><b>PASSWORD :  </b></td><td><label><input type ="password" value={this.state.getpassword} onChange={(event) => this.passwordChangedHandler(event)}/></label></td></tr>
              <br></br>
              <tr><td><input className="button" type="submit" value="Login"/></td></tr>
              </tbody>
              </table>
              <br></br><br></br>
              </form>
              </center>
              </div>
    );
    }
}
    export default Login;