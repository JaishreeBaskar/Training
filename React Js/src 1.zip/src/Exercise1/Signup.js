import React from 'react';
import AddressComponent from './AddressComponent';

    class Signup extends React.Component{

    state={
        getid: '',
        getname: '',
        getmobilenumber: '',
        getpassword: '',
        getusername: '',
        getemail:'',
        getwebsite: '',
        getstreet:'',
        getsuite: '',
        getlat: '',
        getlng: '',
        getzipcode: '',
        getcity: ''

    };

    idChangedHandler = (event) => {
        const updatedid = event.target.value;
        this.setState({getid:updatedid})
        console.log(updatedid);
    }
    nameChangedHandler = (event) => {
        const updatedname = event.target.value;
        this.setState({getname:updatedname})
        console.log(updatedname);
    }
    usernameChangedHandler = (event) => {
        const updatedusername = event.target.value;
        this.setState({getusername:updatedusername})
        console.log(updatedusername);
    }
    passwordChangedHandler = (event) => {
        const updatedpassword = event.target.value;
        this.setState({getpassword:updatedpassword})
        console.log(updatedpassword);
    }
    emailChangedHandler = (event) => {
        const updatedemail = event.target.value;
        this.setState({getemail:updatedemail})
        console.log(updatedemail);
    }
    websiteChangedHandler = (event) => {
        const updatedwebsite = event.target.value;
        this.setState({getwebsite:updatedwebsite})
        console.log(updatedwebsite);
    }
    mobilenumberChangedHandler = (event) => {
        const updatedmobilenumber = event.target.value;
        this.setState({getmobilenumber:updatedmobilenumber})
        console.log(updatedmobilenumber);
    }

    setstreetChangedHandler = (event) => {
        const updatedstreet =  event.target.value;
        this.setState({getstreet: updatedstreet})
        console.log(updatedstreet);
    }

    setsuiteChangedHandler = (event) => {
        const updatedsuite =  event.target.value;
        this.setState({getsuite: updatedsuite})
        console.log(updatedsuite);
    }

    setcityChangedHandler = (event) => {
        const updatedcity =  event.target.value;
        this.setState({getcity: updatedcity})
        console.log(updatedcity);
    }

    setzipcodeChangedHandler = (event) => {
        const updatedzipcode =  event.target.value;
        this.setState({getzipcode: updatedzipcode})
        console.log(updatedzipcode);
    }

    setlatChangedHandler = (event) => {
        const updatedlat =  event.target.value;
        this.setState({getlat: updatedlat})
        console.log(updatedlat);
    }

    setlngChangedHandler = (event) => {
        const updatedlng =  event.target.value;
        this.setState({getlng: updatedlng})
        console.log(updatedlng);
    }

    clicksubmit = (event) => {
        event.preventDefault();
        console.log(this.state);
        console.log("signup clicked");
    }

    render(){
        return(
            <div className="signup">
                <center>
                <form onSubmit={(event) => this.clicksubmit(event)}>
                  <h1> SIGNUP </h1> <br></br>   
                  <table>
                            <tbody>                       
                          <tr><td><b>ID : </b></td><td><label><input type ="text" value={this.state.getid} onChange={(event) => this.idChangedHandler(event)}/></label></td></tr>
                          <tr><td><b>NAME : </b></td><td><label><input type ="text" value={this.state.getname} onChange={(event) => this.nameChangedHandler(event)}/></label></td></tr>
                          <tr><td><b>USER NAME : </b></td><td><label><input type ="text" value={this.state.getusername} onChange={(event) => this.usernameChangedHandler(event)}/></label></td></tr>
                          <tr><td><b>PASSWORD :  </b></td><td><label><input type ="password" value={this.state.getpassword} onChange={(event) => this.passwordChangedHandler(event)}/></label></td></tr>
                          <tr><td><b>MOBILE NUMBER :  </b></td><td><label><input type ="text" value={this.state.getmobilenumber} onChange={(event) => this.mobilenumberChangedHandler(event)}/></label></td></tr>
                          <tr><td><b>EMAIL :  </b></td><td><label><input type ="text" value={this.state.getemail} onChange={(event) => this.emailChangedHandler(event)}/></label></td></tr>
                          <tr><td><b>WEBSITE :  </b></td><td><label><input type ="text" value={this.state.getwebsite} onChange={(event) => this.websiteChangedHandler(event)}/></label></td></tr>
                          <tr><AddressComponent
                          streetChangedHandler={(event)=>this.setstreetChangedHandler(event)}
                          suiteChangedHandler={(event)=> this.setsuiteChangedHandler(event)} 
                          cityChangedHandler={(event)=> this.setcityChangedHandler(event)} 
                          zipcodeChangedHandler={(event)=> this.setzipcodeChangedHandler(event)} 
                          latChangedHandler={(event)=> this.setlatChangedHandler(event)} 
                          lngChangedHandler={(event)=> this.setlngChangedHandler(event)} >
                          </AddressComponent></tr>
                  <tr><td><b><input className="button" type="submit" value="Sign Up"/></b></td></tr>
                  </tbody>
                        </table>
                  </form></center>
                


                    <br></br><br></br><center>
                    <div className="signup1">
                    <form>
                      <h2> Entered SignUp Details : </h2>   
                      <table>
                            <tbody>
                            <tr><td><b>Id : {this.state.getid} </b></td></tr>
                            <tr><td><b>Name : {this.state.getname} </b></td></tr>
                            <tr><td><b>User name : {this.state.getusername} </b></td></tr>
                            <tr><td><b>Password : {this.state.getpassword} </b></td></tr>
                            <tr><td><b>Mobile Number : {this.state.getmobilenumber} </b></td></tr>
                            <tr><td><b>Email : {this.state.getemail} </b></td></tr>
                            <tr><td><b>Address: </b></td></tr>
                            <tr><td><b>Street : {this.state.getstreet}</b></td></tr>
                            <tr><td><b>Suite : {this.state.getsuite} </b></td></tr>
                            <tr><td><b>City : {this.state.getcity} </b></td></tr>
                            <tr><td><b>Zipcode : {this.state.getzipcode} </b></td></tr>
                            <tr><td><b>Latitude : {this.state.getlat} </b></td></tr>
                            <tr><td><b>Longitude : {this.state.getlng} </b></td></tr>
                            </tbody>
                        </table> </form> 
                    </div> </center>                    
            </div>              
      
     );
    }
    }
        export default Signup;