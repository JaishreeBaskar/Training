import React, { Component } from 'react';

class AddPost extends Component {
    state = {
        userId: '',
        id: '',
        title: '',
        body: ''
    }

    titleInputHandler = (event) => {
        this.setState({ title: event.target.value })
    }
    bodyInputHandler = (event) => {
        this.setState({ body: event.target.value })
    }

    addPostHandler = (event) => {
        console.log('Posted successfully');
        console.log(this.state.title);
        console.log(this.state.body);
        //alert("Title : " + this.state.title + "\n" + "Body : " + this.state.body);
        event.preventDefault();
    }
    render() {
        return <div className="container mt-6 addPost">
            <h1><center>Add New Post</center></h1>
            <div className="row">
                <label htmlFor="title"><b>Title&emsp;</b></label>
                <input type="text" id="title" className="input-box" value={this.state.title} onChange={(event) => this.titleInputHandler(event)}></input>
            </div><br></br>
            <div className="row">
                <label htmlFor="body"><b>Body&emsp;</b></label>
                <textarea id="body" rows='5' cols='42' className="input-box" value={this.state.body} onChange={(event) => this.bodyInputHandler(event)}></textarea>
            </div><br></br>
            <div className="row justify-content-center">
                <button className='btn-secondary mb-5' onClick={(event) => this.addPostHandler(event)} type="submit"><b>Post</b></button>
            </div>
  
            <h2>Add Post Details are</h2>
            <h3>Title : </h3>{this.state.title}
            <h3>Body : </h3>{this.state.body}
        </div>;
    }
}

export default AddPost;