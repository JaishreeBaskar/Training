import React, { Component } from 'react';

class Comment extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return <div className="container">
        <div className="row justify-content-center comment">
            <div className="card col-lg-8 m-3">
                <div><b>Name : </b>{this.props.name}</div>
                <div className="card-body"><b>Body : </b>{this.props.body}</div>
                <div className="ml-auto"><button className="btn-sm btn-secondary mb-2" onClick={() => this.props.removeComment(this.props.id)}><b>Delete</b></button></div>
            </div>
        </div>
    </div>
    }
}
export default Comment;
