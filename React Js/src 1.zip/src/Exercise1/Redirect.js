import React from 'react';
import { Route, Switch } from 'react-router';
import { NavLink } from 'react-router-dom';
import Login from './Login';
import Signup from './Signup';
import './Redirect.css'
import NewUserList from './NewUserList';

export default class Redirect extends React.Component {
    render () {
    return <div>
      <header>
      <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
          <ul class="navbar-nav">
           <li class="nav-item">
           <NavLink exact to = {{ pathname: "/Login" }}> LOGIN </NavLink></li>
           <li class="nav-item">
           <NavLink exact to = {{ pathname: "/Signup" }}> SIGNUP </NavLink></li>
           <li class="nav-item">
           <NavLink exact to = {{ pathname: "/NewUserList" }}> USER LISTS </NavLink></li>
           </ul> 
        </nav>
      </header>
  <section>
    <div>
      <Switch>
      <Route path ="/Login" exact component={Login}/>
      <Route path ="/Signup" exact component={Signup}/>
      <Route path ="/NewUserList" exact component={NewUserList}/>
      </Switch>
    </div>
  </section>
</div>
    }
}
