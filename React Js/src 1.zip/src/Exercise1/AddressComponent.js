import React from 'react';

    class AddressComponent extends React.Component{

        constructor(props){
            console.log('Constructor called');
            super(props);}      

    render(){
        return(
                <div className="address">
                  <form>
                      <table>
                          <tbody>
                            <tr><td><b>ADDRESS : </b></td></tr>
                            <tr><td><b>STREET : </b></td><td><label><input type ="text" onChange={(event) => this.props.streetChangedHandler(event)}/></label></td></tr>
                            <tr><td><b>SUITE : </b></td><td><label><input type ="text" onChange={(event) => this.props.suiteChangedHandler(event)}/></label></td></tr>
                            <tr><td><b>CITY : </b></td><td><label><input type ="text" onChange={(event) => this.props.cityChangedHandler(event)}/></label></td></tr>
                            <tr><td><b>ZIP CODE :  </b></td><td><label><input type ="text" onChange={(event) => this.props.zipcodeChangedHandler(event)}/></label></td></tr>
                            <tr><td><b>LATITUDE :  </b></td><td><label><input type ="text" onChange={(event) => this.props.latChangedHandler(event)}/></label></td></tr>
                            <tr><td><b>LONGITUDE :  </b></td><td><label><input type ="text" onChange={(event) => this.props.lngChangedHandler(event)}/></label></td></tr>
                        </tbody>
                      </table> 
                  </form>
                </div>
        );
        }
    }
        export default AddressComponent;