import React, { Component } from 'react';
import axios from 'axios';
import UserPosts from './Userposts';
import Comment from './Comment';

class UserLists extends Component {
    state = {
        users: [
            {
                id: '',
            }
        ],
        posts: [{
            title: '',
            body: ''
        }],
        comments: [{
            name: '',
            body: ''
        }]

    }
    constructor(props) {
        super(props);
    }
    componentDidMount = () => {
        axios.get('https://jsonplaceholder.typicode.com/users')
            .then((response) => {
                const users = response.data;
                this.setState({ users });
                console.log("Users", response.data);
            })
            .catch((error) => {
                console.log("Error getting data");
            })
    }
    viewPostHandler = (id) => {
        axios.get(`https://jsonplaceholder.typicode.com/posts`)
            .then((response) => {
                const posts = response.data;
                console.log(posts)
                const userPosts = posts.filter(post => id === post.userId);
                this.setState({ posts: userPosts });
                console.log(userPosts)
            })
    }

    viewCommentHandler = (id) => {
        axios.get(`https://jsonplaceholder.typicode.com/comments`)
            .then((response) => {
                const comments = response.data;
                console.log(comments)
                const userPosts = comments.filter(post => id === post.postId);
                this.setState({comments: userPosts});
                console.log(userPosts)
            })
    } 
    
    
    removePostHandler = (id) => {
        const posts = [...this.state.posts];
        const otherPosts = posts.filter(i => i.id !== id);
        this.setState({ posts: otherPosts });
        alert('Post deleted successfully');
    }

    removeCommentHandler = (id) => {
        const comments = [...this.state.comments];
        const otherComments = comments.filter(i => i.id !== id);
        this.setState({ comments: otherComments });
        alert('Comment deleted successfully');
    }

    resetPasswordHandler = (id) => {
        prompt("Enter new password", "");
        alert('User' + id + ' password changed successfully')
    }

    render() {
        return (
            <div>
                <div className="container ul">
                    <h3><center>User List</center></h3>
                    <div className="row justify-content-center">
                        <div>
                            <table border='1px solid' className="table-light" >
                                <thead>
                                    <tr >
                                        <th>S.No.</th>
                                        <th><center>Name</center></th>
                                        <th><center>Email</center></th>
                                        <th><center>Action</center></th>
                                    </tr>
                                </thead>
                                {this.state.users.map(user =>
                                    <tbody>
                                        <tr>
                                            <td>{user.id}  </td>
                                            <td>{user.name}</td>
                                            <td>{user.email}</td>
                                            <td>
                                                <button type="button" className="btn-sm btn-secondary" onClick={() => this.resetPasswordHandler(user.id)}>Reset password</button>
                                                &emsp;<button type="button" className="btn-sm btn-primary" onClick={() => this.viewPostHandler(user.id)}> View Posts</button>
                                                &emsp;<button type="button" className="btn-sm btn-primary" onClick={() => this.viewCommentHandler(user.id)}> Comment</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                )}
                            </table>
                        </div>
                    </div>
                </div><br></br>
                <div className="container">
                    <h3><center>User Posts</center></h3>
                    <div> {this.state.posts.map(post =>
                        <UserPosts title={post.title} body={post.body} removePost={() => this.removePostHandler(post.id)} />
                    )}
                    </div>
                    <br></br>
                    <h3><center>User Comments</center></h3>
                    <div> {this.state.comments.map(comment =>
                        <Comment name={comment.name} body={comment.body} removeComment={() => this.removeCommentHandler(comment.id)}/>
                    )}
                    </div>
                </div>
            </div>
        )
    }
}

export default UserLists;