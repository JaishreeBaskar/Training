import React, { Component } from 'react';
import axios from 'axios';
import DataTable from 'react-data-table-component';

class UserList extends Component{
    constructor(props){
        console.log('Constructor called');
        super(props);
        this.state = {
          users : [],
          columns : [
            {
              name: 'Name',
              selector: 'name'
            },
            {
              name: 'Email',
              selector: 'email'
            },
            {
              name: 'Action',
              selector: 'Action',
              cell: row => <div><div><button> Reset Password</button></div></div>

            },
            {
                name: 'Action',
                selector: 'Action',
                cell: row => <div><div><button> Post</button></div></div>
  
              }
          ]
      }
    }

    render() {
        console.log('render called');
        console.log(this.state)
        return <DataTable
        title="User List"
        columns={this.state.columns}
        data={this.state.users}/>
    }

    componentDidMount = () => {
        console.log('componentDidMount called');
        
        axios.get('https://jsonplaceholder.typicode.com/users/')
        .then(response=> {
            // handle success   
            this.setState({
              users:response.data
            })
        });
    }
}

export default UserList;

