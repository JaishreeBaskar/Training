import React from 'react';

const Product = (props) => {
    console.log(props);

const onsale1 = {
    backgroundColor: 'yellow'
}

let actions;
if (props.onsale) {
    actions = <div><button onClick={props.addToCart}>On Sale, Add To cart</button></div>
    onsale1.backgroundColor= 'red';
} else {
    actions = <div><button onClick={props.toggleFav}>Not On Sale, Buy Later</button></div>
}

return(
    <center>
    <div>
        <div className="Product" style={onsale1}>
        <label><b> Id : </b></label>{props.id} <br></br> 
        <label><b> Title : </b></label>{props.title} <br></br>
        <label><b> Price : </b></label>{props.price} <br></br>
        <label><b> onSale : </b></label>{props.onsale ? 'Yes' : 'No' } 
        {actions}
        </div>
   </div>
   </center>
);
}
export default Product;
