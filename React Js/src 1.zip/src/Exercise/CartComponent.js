import React from 'react';

const CartComponent = (props) => {
    return (
        <div>
            <label>Title : </label> {props.title}<br></br>
            <label>Price : </label> {props.price}
        </div>
    )
}

export default CartComponent;