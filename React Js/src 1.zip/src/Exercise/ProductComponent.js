import React,{useState} from 'react';
import Product from './Product';
import CartComponent from './CartComponent';

const ProductComponent = (props) => {
    const products = [
        {
            id: '001',
            title:'mobile' ,
            price: 7800,
            onsale: true,
            number: 1
        },
        {
            id: '002',
            title:'television',
            price: 15000,
            onsale: false,
            number: 1
        },
        {
            id: '003',
            title:'ac' ,
            price: 150000,
            onsale: true,
            number: 1
        },
        {
            id: '004',
            title:'washing machine',
            price: 150000,
            onsale: false,
            number: 1
        },
        {
            id: '005',
            title:'microwave oven' ,
            price: 950000,
            onsale: true,
            number: 1
        },
        {
            id: '006',
            title:'refridgerator' ,
            price: 89600,
            onsale: false,
            number: 1
        }
    ];

const cartList=[];
  const [currState, setState] = useState({products1 : products,cartList1: cartList});
  const copyProducts = [...currState.products1];
  const addItem = (id) => {
   console.log("adding");
    copyProducts.forEach(element => {
      if(element.id===id){
        if(currState.cartList1.length!==0)
        {
          const filterValue=currState.cartList1.filter(element =>{
            return element.id===id;
          });
          console.log(filterValue);
          if(filterValue.length>0) {
            currState.cartList1.forEach(cartElement =>{
              if(cartElement.id===id) {
                cartElement.number+=1;
              }
             
            });
          }
          else {
           
            currState.cartList1.push(element);
          }
         
        }
        else
        {
          currState.cartList1.push(element);
        }
       
      }
    });
    console.log(currState.cartList1);
    console.log(id);

    setState({products1:copyProducts,cartList1:currState.cartList1});
}

const deleteItem = (id) => {
    console.log("clicked"+id);
    copyProducts.forEach(element => {
      if(element.id===id){
        var index=currState.cartList1.indexOf(element);
        console.log(index);
        currState.cartList1.slice(index,1);
      }
    });
    console.log(currState.cartListing);
    setState({products1:copyProducts,cartList1:currState.cartList1});
  }

  const mappedProduct = products.map(p => {
    return <Product key={p.id}
      id={p.id}
      title={p.title}
      price={p.price}
      onsale={p.onsale}
      
      addToCart={()=> addItem(p.id) }>
    </Product>
  });

  let totalPrice=0;
  const mappedCart = currState.cartList1.map(p => {
    totalPrice+=(p.price*p.number);
    return <CartComponent key={p.id}
    id={p.id}
    title={p.title}
    price={p.price}
    number={p.number}
    
    deleteCart={()=> deleteItem(p.id)}>
    </CartComponent>
  });
 
  let totalElementPrice;

  if(totalPrice>0)
  {
  totalElementPrice=<center><div>
    <h1> Your Cart </h1>
  <div>
     <b> {mappedCart} </b>
    </div>
    <h1>Total price ={totalPrice}</h1>
    </div></center>
  }

return (
    <div>
    <div>
      {mappedProduct}
    </div>
    <div>
      {totalElementPrice}
    </div>
    </div>
  );
  }
export default ProductComponent;