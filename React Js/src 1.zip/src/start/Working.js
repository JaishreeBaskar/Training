const redux = require('redux');

//1
const createStore = redux.createStore;

//2
const initialState = {counter : 20}

//4
const reducer = (state = initialState, action) => {
if(action.type == 'INC_COUNTER'){
    return {
        ...state,
        counter: state.counter + 1
    }
}
    if(action.type == 'ADD_COUNTER'){
        return {
            ...state,
            counter: state.counter + 2
        }
    }
    else if(action.type == 'ADD_COUNTER1'){
        return {
            ...state,
            counter: state.counter +action.value
        }
    }
        return state;
    }

const store = createStore(reducer);

//5
store.subscribe(()=> {
    console.log('state in store: ' , store.getState());
});

//3
store.dispatch({type: 'INC_COUNTER'});
store.dispatch({type: 'ADD_COUNTER'});
store.dispatch({type: 'ADD_COUNTER1', value: 5});