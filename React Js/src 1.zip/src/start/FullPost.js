import React, {useEffect, useState} from 'react';
import axios from 'axios';
import './FullPost.css';

const FullPost = (props) => {

    const [post, setPost] = useState({title:'', body: ''});

    useEffect(() => {
        console.log(props);
        const postId = props.match.params.id;
      //  const postId = props.postId;
        axios.get('https://jsonplaceholder.typicode.com/posts/'+postId)
        .then(res => {
            setPost({title:res.data.title, body:res.data.body});
        })
    }, []);

    return <div className='FullPost'>
        <h3>{post.title}</h3>
        <p>{post.body}</p>
    </div>
}

export default FullPost;