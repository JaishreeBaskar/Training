import React from 'react';
import axios from 'axios';
import Post from './Post';
import { Link, Route } from 'react-router-dom';
import FullPost from './FullPost';

export default class Posts extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            posts: []
        }
    }

    componentDidMount() {
        axios.get('https://jsonplaceholder.typicode.com/posts')
        .then(res => {
            const posts = res.data.slice(0,4);
            this.setState({posts});
        });
    }

    postClickedHandler = (id) => {
        console.log('clicked' +id);
        this.props.history.push({pathname: '/' +id})
    }

    render () {
        return <div>
            {
                this.state.posts.map(post => {
                    return <div key={post.id}>
                        {/* <Link to={"/" + post.id}> */}
                        <Post post={post} clicked={()=>this.postClickedHandler(post.id)}/>
                        {/* </Link> */}
                        </div>
                })
                }
                {/* <Route path = "/:id" component={FullPost}></Route> */}
                {/* on adding above, remove id path | for declaring clicked values in the same page*/}
        </div>
    }
} 