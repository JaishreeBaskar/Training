import React from 'react';
import Posts from './Posts';
import FullPost from './FullPost';
import NewPost from './NewPost';
import './Blog.css';
import { Route, Switch } from 'react-router';
import { NavLink } from 'react-router-dom';

export default class Blog extends React.Component {

    render () {
        return <div>
            <header>
                <ul>
                    {/* <li><a href="/">Home</a></li> */}
                    <li><NavLink exact to = "/">Home</NavLink></li>
                    <li><NavLink to = {{
                        pathname: "/new-post" }}> New Post </NavLink> </li>
                    {/* <li><Link to="/new-post">New Post</Link></li> */}
                    {/* <li><a href="/new-post">New Post</a></li> */}
                </ul>
            </header>
            <section>
                <div style={{clear:'both'}}>
                    {/* <Posts/>
                    <FullPost postId="1"/>
                    <NewPost/> */}
                   
                    <Route path ="/" exact component={Posts}/>
                    <Switch>
                    <Route path = "/new-post" component={NewPost}/>
                    <Route path = "/:id" component={FullPost}/>
                    </Switch>
                </div>
            </section>
        </div>
    }

}