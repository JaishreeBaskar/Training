import React from 'react';
import { connect } from 'react-redux';
import * as actionCreactor from './Action'

const mapStateToprops = state => {
    return {
        ctr:state.counter,
        storedResult:state.results,
    };
};

 const mapDispatchToPros = dispatch => {
    
    return {
        
        
        onSignupCounter: () =>
        {
            
            dispatch(actionCreactor.onSignupCounter())
        },

        onSignup: (val) =>
        {
            
            dispatch(actionCreactor.onSignup(val))
        },
        // onSignup1: (val) =>
        // {
            
        //     dispatch(actionCreactor.onSignup1(val))
        // }
        
    };
};

 class SignUp extends React.Component  {


    formSignupHandler = (event) => {
        
        const name=event.target.username.value;
        console.log("Name is " +name);

        const password=event.target.password.value;
        console.log("Password is " +password);

        const email=event.target.email.value;
        console.log("Email is " +email);

        const mobilenumber=event.target.mobilenumber.value;
        console.log("Mobile Number is " +mobilenumber);
        
        this.props.onSignupCounter();
        this.props.onSignup(name);
        this.props.onSignup(password);
        this.props.onSignup(email);
        this.props.onSignup(mobilenumber);
        event.preventDefault();
    }
    render () {
        return(
            [
                <div className="signup">
                <center>
                  <h1> SIGNUP </h1> <br></br>   
            
            <form onSubmit={this.formSignupHandler} className="loginForm">
                <label>Username : </label>&nbsp;
                <input type="text" name="username" /><br /><br />

                <label>Password : </label>&nbsp;
                <input type="password" name="password" /><br /><br />

                <label>Email : </label>&nbsp;
                <input type="email" name="email" /><br /><br />

                <label>Mobile Number : </label>&nbsp;
                <input type="text" name="mobilenumber" /><br /><br />
                
                <button type="submit">SignUp</button><br /><br />
            </form>

        <div>
            <h2>List of Signed Up Users : </h2>
                {
                    this.props.storedResult.map(result=>{
                    return<div>{result.value}</div>
                    })
                }
                 <h6>No of Users :{this.props.ctr}</h6>
        </div></center></div>
        ]
        )
}
}

export default connect(mapStateToprops,mapDispatchToPros)(SignUp);