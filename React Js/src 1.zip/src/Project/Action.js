export const ON_SIGNUP_COUNTER='ON_SIGNUP_COUNTER';
export const ON_SIGNUP='ON_SIGNUP';
// export const ON_SIGNUP1='ON_SIGNUP1';
export const onSignupCounter=()=>{
    return {
        type:ON_SIGNUP_COUNTER,
       
    }
}

export const onSignup=(value)=>{
    console.log(value);
    return {
        type:ON_SIGNUP,
        value:value
       
    }
}

// export const onSignup1=(value)=>{
//     console.log(value);
//     return {
//         type:ON_SIGNUP1,
//         value:value
       
//     }
// }