import React from 'react';
import './App.css';
//import Redirect from './Exercise1/Redirect';
//import Blog from './start/Blog';
import { BrowserRouter } from 'react-router-dom';
import Counter from './redux/learn/Counter';
import MainComponent from './Project/MainComponent';
import Todos from './unit-testing/Todos';
//import ErrorBoundary from './Example/ErrorBoundary';
//import WithError from './Example/WithError';
//import ErrorExample from './Example/ErrorExample';
//import UserLists from './Exercise1/UserLists';
//import Comment from './Exercise1/Comment';
//import AddPost from './Exercise1/Addpost';
//import UserPosts from './Exercise1/Userposts';
//import Posts from './Exercise1/Posts';
//import Signup from './Exercise1/Signup';
//import Login from './Exercise1/Login';
//import ProductComponent from './Exercise/ProductComponent';

function App() {
  return (
    //<ProductComponent/>
    //<Login/>
    //<Signup/>
    //<AddPost/>
    //<UserPosts/>
    //<Posts/>
    //<UserLists/>
    //<Comment/>

    //with routing
    // <BrowserRouter>
    //   <div className= 'App'>
    //     <Redirect/>
    //  </div>
    // </BrowserRouter>

   
    //Day3 
    // <ErrorBoundary>
    // <WithError/>
    // </ErrorBoundary>

    //routing
    // <BrowserRouter>
    // <div className= 'App'>
    // <Blog/>
    // </div>
    // </BrowserRouter>

    //Day4 redux
    // <BrowserRouter>
    // <Counter/>
    // </BrowserRouter>

    //Day 4-Project
    // <BrowserRouter>
    //   <div className= 'App'>
    //      <MainComponent/>
    //   </div>
    //  </BrowserRouter>

    //day 5 testing
    <Todos/>
  );
}

export default App;
