import React from 'react';
import WithError from './WithError';
import ErrorBoundary from './ErrorBoundary';


const ErrorExample = () => {

    return (
        <div>
            <ErrorBoundary>
                <WithError/>
                </ErrorBoundary>
        </div>
    )
}

export default ErrorExample;
