import React from 'react';

const WithError = () => {

    const rnd = Math.random();

    if(rnd > 0.7){
        throw new Error("Something went wrong")
    }

    return <div style = {{width: '300px', height: '100px', backgroundColor: 'grey'}}>
    WithError </div>
}

export default WithError;