import React from 'react';

const TodoItem = (props) => {
    return <div className="item">
        <div>{props.item.title}</div>
        {
            props.item.completed ? 
            (props.item.archived ? 'Archived' : <button onClick={props.archive}>Archive</button>) : 
                <button onClick={props.complete}>Complete</button>
        }
        
    </div>
}
export default TodoItem;