import reducer from './TodoReducer';

describe('todo reducer', () => {
    it('should return initial state', () => {
        expect(reducer(undefined, {})).toEqual({
            todos: [],
            special: false
        });
    });
    it('should add item and return state', () => {
        expect(reducer({todos:[], special:false},{type:'ADD_ITEM',item:{title:'Test'}}))
        .toEqual({todos:[{id:'Test',title:'Test'}],special:false});
    });
});
