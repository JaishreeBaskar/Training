import React from 'react';
import {connect} from 'react-redux';
import TodoItem from './TodoItem';
import ActionItems from './ActionItems';

export class TodoList extends React.Component {
    render() {
        return <div>
            {
                this.props.spl ? <ActionItems/> : null
            }
            {
                this.props.items.map(item => {
                    return <TodoItem key={item.id} item={item}
                        archive={()=>this.props.onItemArchive(item.id)}
                        complete={()=>this.props.onItemComplete(item.id)}/>
                })
            }
        </div>
    }
}

const mapStateToProps = state => {
    return {
        items: state.todos,
        spl: state.special
    }
}
const mapDispatchToProps = dispatch => {
    return {
        onItemComplete: (id) => dispatch({type:'COMPLETE_ITEM', id}),
        onItemArchive: (id) => dispatch({type:'ARCHIVE_ITEM', id}),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(TodoList);