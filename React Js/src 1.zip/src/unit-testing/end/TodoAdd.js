import React, {useState} from 'react';
import {connect} from 'react-redux';

const TodoAdd = (props) => {
    const [title,setTitle] = useState('');
    return <div className="addTodo">
        <input type="text" onChange={(e)=>{setTitle(e.target.value)}} value={title}></input>
        <button onClick={()=>props.onItemAdd(title)}>Add</button>
    </div>
}

const mapDispatchToProps = dispatch => {
    return {
        onItemAdd: (title) => dispatch({type:'ADD_ITEM',
         item:{title, completed:false, archived:false}})
    }
}
export default connect(null, mapDispatchToProps)(TodoAdd);