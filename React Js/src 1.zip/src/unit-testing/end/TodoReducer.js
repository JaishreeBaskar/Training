const initialState = {
    todos: [],
    special: false
}

const todoReducer = (state = initialState, action) => {
    if(action.type === 'ADD_ITEM') {
        return {
            ...state,
            todos: state.todos.concat({...action.item, id:action.item.title})
        }
    }
    else if(action.type === 'COMPLETE_ITEM') {
        const copy = [...state.todos];
        copy.forEach(i=>{
            if(i.id===action.id){
                i.completed = true;
            }
        })
        return {
            ...state,
            todos: copy
        }
    }
    else if(action.type === 'ARCHIVE_ITEM') {
        const copy = [...state.todos];
        copy.forEach(i=>{
            if(i.id===action.id){
                i.archived = true;
            }
        })
        return {
            ...state,
            todos: copy
        }
    }
    return state;
}

export default todoReducer;