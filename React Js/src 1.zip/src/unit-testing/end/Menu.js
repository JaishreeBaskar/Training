import React, { Fragment } from 'react';
import MenuItem from './MenuItem';

const Menu = (props) => {
    return <div className="Menu">
        <MenuItem path="/">Home</MenuItem>
        {
            props.authenticated ?
            <MenuItem path="/logout">Logout</MenuItem>:
            <Fragment><MenuItem path="/login">Login</MenuItem>
            <MenuItem path="/signup">Sign Up</MenuItem></Fragment>
        }
    </div>
}

export default Menu;