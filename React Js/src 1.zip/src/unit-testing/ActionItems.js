import React from 'react';

const ActionItems = (props) => {
    return <ul><li>Delete</li></ul>
}
export default ActionItems;